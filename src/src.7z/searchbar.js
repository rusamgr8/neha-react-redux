import React, {Component} from 'react';

class SearchBar extends Component {
  render() {
    return (
      <div>
        <input type="text" name="search" />
      </div>
    );
  }
}

export default SearchBar;
